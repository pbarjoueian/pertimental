A Python Persian Text sentiment Analyser
=======================

A package for determining sentiment score of Persian text. I used NLTK, Hazm packages and Naive Bayes classifier for this purpose.
